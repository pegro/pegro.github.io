﻿# Imagickimg extension for TYPO3 CMS

Since version 0.3.1 Imagickimg works with TYPO3 6.2. Version 0.4.0 will work with TYPO4 version 7 branch.


Icon was taken from
http://www.iconarchive.com/show/flatastic-6-icons-by-custom-icon-design/Magic-wand-icon.html
Icon author is: Custom Icon Design
