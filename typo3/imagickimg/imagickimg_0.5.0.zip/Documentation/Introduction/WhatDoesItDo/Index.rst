.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt


.. _introduction-what-does-it-do:

What does it do?
----------------

This extension provides image processing with PHP extension Imagick. Uses object oriented classes
instead of ImageMagick commands. It is useful on servers where exec() function is disabled for
security reasons.
