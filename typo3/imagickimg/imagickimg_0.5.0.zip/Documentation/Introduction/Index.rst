.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _introduction:

Introduction
============

.. toctree::
    :maxdepth: 2
    :titlesonly:

    WhatDoesItDo/Index
    FeaturesList/Index
