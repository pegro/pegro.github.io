.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../../Includes.txt


.. _introduction-features-list:

Features list
-------------

#. Resizes images in FE and BE.
#. Creates thumbnails in BE.
#. Removes from the images profiles which reduces image sizes.
#. Does some image optimization.
#. Allows you to use all image effects available in standard content elements like Images, Text with images.
#. Adds three new effects: polaroid, round corners and sepia.
#. Provides extensive image information in the file browser. Just click on the Info icon to see. Availeble in File -> Filelist module when "Extended view" is enabled.
#. Informs you if you disabled PHP extension imagick in modules Help -> About Modules and in System -> Reports.
