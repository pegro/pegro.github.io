.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _known-problems:

Known problems
==============

Please post bur reports and request for features on the project forge:

http://forge.typo3.org/projects/extension-imagickimg/issues
