.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _installation:

Installation
============

#. Download and install extension ImagickImg from the TER.
#. Configure the extension or leave its default values.
#. Done.
